
document.addEventListener("DOMContentLoaded", () => {
    console.log("KORMI Batanghari Website Loaded.");
});
